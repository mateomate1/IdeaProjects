package com.dam.di.gestion.gestiondeservicios;

public class QUERRYS {
    public static final String
        INSERTAR_USUARIO = "INSERT INTO Usuario(username, password_key) VALUES (?,?)";
    
}
