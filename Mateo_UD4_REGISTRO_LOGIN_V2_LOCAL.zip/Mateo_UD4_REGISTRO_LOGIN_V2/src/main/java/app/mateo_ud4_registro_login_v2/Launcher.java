package app.mateo_ud4_registro_login_v2;

import javafx.application.Application;

public class Launcher {

    public static void main(String[] args) {
        Application.launch(HelloApplication.class, args);
        /*
        DBManager db = new DBManager();
        db.addUser("Mateo", "Ayarra");
        int i = db.contarUsuarios();
        System.out.println(i);
        */
    }
}
